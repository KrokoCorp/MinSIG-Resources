/*
 * src/include/port/win32/sys/wait.h
 */
