DROP TABLE IF EXISTS pgreg.loadedshp;
--DELETE FROM geometry_columns WHERE f_table_schema='pgreg';
DROP SCHEMA pgreg;
