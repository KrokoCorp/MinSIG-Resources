link "loader/testraster2.tif", "loader/TiledAuto.tif";
