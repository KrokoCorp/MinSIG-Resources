unlink "loader/TiledAuto.tif";
