link "loader/testraster2.tif", "loader/TiledAutoSkipNoData.tif";
