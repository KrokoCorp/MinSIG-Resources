/* raster/raster_config.h.  Generated from raster_config.h.in by configure.  */
/* raster_config.h.in.  Generated from configure.ac by autoheader.  */

/* GDAL library version */
#define POSTGIS_GDAL_VERSION 21

/* Enable development variable */
/* #undef ENABLE_DEVELOPMENT */

/* Define to 1 if a warning is outputted every time a double is truncated */
#define POSTGIS_RASTER_WARN_ON_TRUNCATION 0
