#ifndef SXOVER_H
#define SXOVER_H

#define ATL_3NB 144
#define NN_MNK_M 43200
#define NN_MNK_N 106032
#define NN_MNK_MN 23040
#define NN_MNK_K 134832
#define NN_MNK_GE 103823
#define NT_MNK_M 43200
#define NT_MNK_N 43200
#define NT_MNK_MN 23040
#define NT_MNK_K 69312
#define NT_MNK_GE 226981
#define TN_MNK_M 43200
#define TN_MNK_N 106032
#define TN_MNK_MN 69120
#define TN_MNK_K 43200
#define TN_MNK_GE 27000
#define TT_MNK_M 69312
#define TT_MNK_N 106032
#define TT_MNK_MN 69120
#define TT_MNK_K 106032
#define TT_MNK_GE 27000

#endif
