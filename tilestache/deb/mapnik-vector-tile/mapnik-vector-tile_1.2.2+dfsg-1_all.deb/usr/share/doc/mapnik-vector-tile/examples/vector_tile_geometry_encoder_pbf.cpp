#include "vector_tile_geometry_encoder_pbf.hpp"
#include "vector_tile_geometry_encoder_pbf.ipp"
