// TODO - remove this file at mapnik 3.x
#ifdef _MSC_VER
#pragma NOTE("filter_factory.hpp" is now called "expression.hpp")
#else
#warning "filter_factory.hpp" is now called "expression.hpp"
#endif

#include <mapnik/expression.hpp>
