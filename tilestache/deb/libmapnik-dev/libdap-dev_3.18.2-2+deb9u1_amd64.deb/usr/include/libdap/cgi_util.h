/*
 * cgi_util.h
 *
 * Compatibility header file. Use <mime_util.h> instead.
 *
 *  Created on: Aug 27, 2009
 *      Author: jimg
 */

#ifndef CGI_UTIL_H_
#define CGI_UTIL_H_

#include <mime_util.h>

#endif /* CGI_UTIL_H_ */
