tilestache-server.py -c zoom_example.cfg -i 127.0.0.1 -p 7890
