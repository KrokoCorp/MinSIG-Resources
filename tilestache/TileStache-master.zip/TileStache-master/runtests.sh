#!/bin/bash
nosetests -v --with-coverage --cover-package TileStache
