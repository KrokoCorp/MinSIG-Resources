""" Additional cache classes go here.
"""