-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION osml10n" to load this file. \quit

-- enable ICU any-latin transliteration function -----------------------------------------------------------------

CREATE OR REPLACE FUNCTION osml10n_kanji_transcript(text)RETURNS text AS
'$libdir/osml10n_kanjitranscript', 'osml10n_kanji_transcript'
LANGUAGE C STRICT;

-- enable libkakasi based kanji transcription function -----------------------------------------------------------------

CREATE OR REPLACE FUNCTION osml10n_translit(text)RETURNS text AS
'$libdir/osml10n_translit', 'osml10n_translit'
LANGUAGE C STRICT;

-- pl/pgSQL code from file geo_transliterate.sql -----------------------------------------------------------------
/*
   osml10n_geo_translit
   
   a geolocation aware transliteration function if no koordinates are given
   fall back to generic transliteration 

   (c) 2015-2016 Sven Geggus <svn-osm@geggus.net>
   
   Licence AGPL http://www.gnu.org/licenses/agpl-3.0.de.html
   
   usage examples:
   select osml10n_geo_translit('東京',ST_Transform(ST_GeomFromText('POINT(137 35)',4326),3857));
    ---> "toukyou"
    
   select osml10n_geo_translit('東京');
    ---> "dōng jīng"
   
*/

CREATE or REPLACE FUNCTION osml10n_geo_translit(name text, place geometry DEFAULT NULL) RETURNS TEXT AS $$
  DECLARE
    country text;
    thai_rm text;
  BEGIN
    -- RAISE LOG 'going to transliterate %', name;
    IF (place IS NULL) THEN
      return osml10n_translit(name);
    ELSE
      /* 
         Look up the country where the geometry is located and call
         the specific transliteration function.
        
         Currently japan and thailand are treated defferently, but other country
         specific transliteration functions can be easily added
      */
      country=osml10n_get_country(place);

      CASE
        WHEN country='jp' THEN
          /* call osml10n_kanji_transcript only on cjk charakters
             not on hiragana and katakana
          */
          if osml10n_contains_cjk(name) THEN
            return osml10n_kanji_transcript(name);
          ELSE
            return osml10n_translit(name);
          END IF;
        WHEN country='th' THEN
          -- Call 'osml10n_thai_transcript' only if available
          IF EXISTS (SELECT 1 from pg_proc where proname = 'osml10n_thai_transcript') THEN
            thai_rm=osml10n_thai_transcript(name);
            IF (thai_rm IS NULL) THEN
              return osml10n_translit(name);
            ELSE
              return thai_rm;
            END IF;
          END IF;
          return osml10n_translit(name);
        ELSE
          return osml10n_translit(name);
      END CASE;

      return osml10n_translit(name);
    END IF;
  END;
$$ LANGUAGE plpgsql STABLE;

-- pl/pgSQL code from file get_country_name.sql -----------------------------------------------------------------
/*
renderer independent name localization
used in german mapnik style available at

https://github.com/giggls/openstreetmap-carto-de

(c) 2016 Sven Geggus <svn-osm@geggus.net>

Licence AGPL http://www.gnu.org/licenses/agpl-3.0.de.html
*/

/*
Get country name by avoiding using the generic name tag altogether

This will take advantage of the fact that countries are usually tagged in a
very extensive manner.

We are thus going to generate a combined string of our target language and
additional names in the official language(s) of the respective countries.

Official languages are taken from the following website:
http://wiki.openstreetmap.org/wiki/Nominatim/Country_Codes

*/

CREATE or REPLACE FUNCTION osml10n_get_country_name(tags hstore, separator text DEFAULT chr(10), targetlang text DEFAULT 'de') RETURNS TEXT AS $$
 DECLARE
  names text[];
  tag text;
  offlangs text[];
  lang text;
  ldistmin int=1;
  ldist int;
  ldistall int;
  str text;
 BEGIN
  -- First add the name in our target language
  tag := 'name:' || targetlang;
  IF tags ? tag THEN
    names=array_append(names,tags->tag);
  END IF;
  -- get the official language(s) of the country from country_languages table
  SELECT langs into offlangs from country_languages where iso = lower(tags->'ISO3166-1:alpha2');
  -- generate an array of all official language names
  IF offlangs IS NOT NULL THEN
    FOREACH lang IN ARRAY offlangs
    LOOP
       tag := 'name:' || lang;
       -- raise notice 'tag: %->%',tag,tags->tag;
       IF tags ? tag THEN
         -- raise notice 'vorhanden';
         -- only append string if levenshtein distance is > ldistmin
         IF names IS NOT NULL THEN
           -- make shure that ldistall is always bigger than ldistmin by default
           ldistall=ldistmin+1;
           FOREACH str IN ARRAY names
           LOOP
             -- raise notice 'loop: % %',str,tags->tag;
             ldist=levenshtein(str,tags->tag);
             if (ldistall > ldist) THEN
               ldistall=ldist;
             END IF;
             -- raise notice 'ldistall: %',ldistall;
           END LOOP;
           if (ldistall > ldistmin) THEN
             names=array_append(names,tags->tag);
           END IF;
         ELSE
           -- raise notice 'names NULL: %',tag;
           names=array_append(names,tags->tag);
         END IF;
       END IF;
    END LOOP;
  END IF;
  IF names IS NULL THEN
    return tags->'name';
  END IF;
  return array_to_string(names,separator);
 END;
$$ LANGUAGE 'plpgsql' STABLE;

-- pl/pgSQL code from file get_country.sql -----------------------------------------------------------------
/*

osml10n_get_country function

determine which country the centroid of a geometry object is located

a table called country_osm_grid is required to make this work

It can be downloaded from nominatim git at:
http://www.nominatim.org/data/country_grid.sql.gz

(c) 2015-2016 Sven Geggus <svn-osm@geggus.net>

example call:

yourdb=# select osml10n_get_country(ST_GeomFromText('POINT(9 49)', 4326));
 get_country 
 -------------
  de
  (1 row)
  
*/

CREATE or REPLACE FUNCTION osml10n_get_country(feature geometry) RETURNS TEXT AS $$
 DECLARE
  country text;
 BEGIN
   SELECT country_code into country
   from country_osm_grid
   where st_contains(geometry, st_centroid(st_transform(feature,4326)));
   return country;
 END;
$$ LANGUAGE 'plpgsql' STABLE;

-- pl/pgSQL code from file get_localized_name_from_tags.sql -----------------------------------------------------------------
/*
renderer independent name localization
used in german mapnik style available at

https://github.com/giggls/openstreetmap-carto-de

(c) 2016-2018 Sven Geggus <svn-osm@geggus.net>

Licence AGPL http://www.gnu.org/licenses/agpl-3.0.de.html
*/

/* 
   helper function "osml10n_is_latin"
   checks if string consists of latin characters only
*/
CREATE or REPLACE FUNCTION osml10n_is_latin(text) RETURNS BOOLEAN AS $$
  DECLARE
    i integer;
  BEGIN
    FOR i IN 1..char_length($1) LOOP
      IF (ascii(substr($1, i, 1)) > 591) THEN
        RETURN false;
      END IF;
    END LOOP;
    RETURN true;
  END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_contains_cjk"
  checks if string contains CJK characters
  = 0x4e00-0x9FFF in unicode table
*/
CREATE or REPLACE FUNCTION osml10n_contains_cjk(text) RETURNS BOOLEAN AS $$
  DECLARE
    i integer;
    c integer;
  BEGIN
    FOR i IN 1..char_length($1) LOOP
      c = ascii(substr($1, i, 1));
      IF ((c > 19967) AND (c < 40960)) THEN
        RETURN true;
      END IF;
    END LOOP;
    RETURN false;
  END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_gen_combined_name"
   Will create a name+local_name pair
   
   In case use_tags is true the combination might be re-created manually
   from a name:xx tag using the requested separator instad of name
   using a somewhat heuristic algorithm (see below)
   
   
*/       
CREATE or REPLACE FUNCTION osml10n_gen_combined_name(local_name text,
                                                     name text,
                                                     tags hstore,
                                                     loc_in_brackets boolean,
                                                     show_brackets boolean DEFAULT true,
                                                     separator text DEFAULT ' ',
                                                     is_street boolean DEFAULT false,
                                                     use_tags boolean DEFAULT false,
                                                     non_latin boolean DEFAULT false) RETURNS TEXT AS $combined$
 DECLARE
   nobrackets boolean;
   found boolean;
   regex text;
   unacc text;
   unacc_local text;
   unacc_tag text;
   tag text;
   langcode text;
   n text;
   ln text;
   pos int;
 BEGIN
  IF NOT tags ? 'name' THEN
    IF is_street THEN
      langcode=substring(local_name from position(':' in local_name)+1 for char_length(local_name));
      return(osml10n_street_abbrev(tags->name,langcode));
    ELSE
      return(tags->name);
    END IF;
  END IF;
  nobrackets=false;
  /* Now we need to do some heuristic to check if the generation of a
     combined name is a good idea.
  
     Currently we do the following:
     If use_tags is false:
     If local_name is part of name as a single word, not just as a substring
     we return name and discard local_name.
     Otherwise we return a combined name with name and local_name
     
     If use_tags is true:
     If local_name is part of name as a single word, not just as a substring
     we try to extract a second valid name (defined in "name:*" as a single word)
     from "name". If succeeeded we redefine name and also return a combined name.
     
     This is useful in bilingual areas where name usually contains two langages.
     E.g.: name=>"Bolzano - Bozen", target language="de" would be rendered as:
     
     Bozen
     Bolzano
     
     
  */
  unacc = unaccent(tags->name);
  unacc_local = unaccent(tags->local_name);
  found = false;
  pos=position(unacc_local in unacc);
  if (pos >0) THEN
    /* the regexp_replace function below is a quotemeta equivalent 
       http://stackoverflow.com/questions/11442090/implementing-quotemeta-q-e-in-tcl/11442113
    */
    regex = '[\s\(\)\-,;:/\[\]](' || regexp_replace(unacc_local, '[][#$^*()+{}\\|.?-]', '\\\&', 'g') ||')[\s\(\)\-,;:/\[\]]';
    -- raise notice 'regex: %',regex;
    IF regexp_matches(concat(' ',unacc,' '),regex) IS NOT NULL THEN
      /* try to create a better string for combined name than plain name */
      /* do these complex checks only in case unaccented name != unaccented local_name */
      IF (char_length(unacc_local) = char_length(unacc)) THEN
        IF is_street THEN
          langcode=substring(local_name from position(':' in local_name)+1 for char_length(local_name));
          return(osml10n_street_abbrev(tags->name,langcode));
        ELSE
          return(tags->name);
        END IF;
      END IF;
      IF tags IS NULL THEN
        nobrackets=true;
      ELSE
        FOREACH tag IN ARRAY akeys(tags)
        LOOP
          IF (tag ~ '^name:.+$') THEN
            unacc_tag = unaccent(tags->tag);
            IF (unacc_tag != unacc_local) THEN
              regex = '[\s\(\)\-,;:/\[\]](' || regexp_replace(unacc_tag, '[][#$^*()+{}\\|.?-]', '\\\&', 'g') ||')[\s\(\)\-,;:/\[\]]';
              IF regexp_matches(concat(' ',unacc,' '),regex) IS NOT NULL THEN
                /* As this regex is also true for 1:1 match we need to ignore this special case */
                if ('name' != tag) THEN
                  -- raise notice 'using % (%) as second name', tags->tag, tag;
                  /* we found a 'second' name */
                  /* While a request might want to prefer printing this
                     second name first anyway, to prefer on the ground
                     language over l10n we pretend to know better in one 
                     special case:
                     
                     if the name in our target language is the first one in
                     the generic name tag we will likely also want to print
                     it first in l10n output.
                     
                     This will make a lot of sense in bilingual areas where
                     mappers usually use the convention of putting the more
                     important language first in bilingual generic name tag.
                     
                     So just remove the "loc_in_brackets = false" assignment
                     if you want to get rid of this fuzzy behaviour!
                     
                     Probably it might be a good idea to add an additional
                     strict option to disable this behaviour.
                  */
                  if (pos = 1) THEN
                    IF regexp_match(substring(unacc,length(unacc_local)+1,1),'[\s\(\)\-,;:/\[\]]') IS NOT NULL THEN
                      raise notice 'swapping primary/second name';
                      loc_in_brackets = false;
                    END IF;
                  END IF;
                  name = tag;
                  nobrackets=false;
                  found=true;
                  langcode=substring(name from position(':' in name)+1 for char_length(name));
                  EXIT;
                ELSE
                  nobrackets=true;
                END IF;
              ELSE
                nobrackets=true;
              END IF;
            END IF;
          END IF;
        END LOOP;
        /* consider other names than local_name crap in case we did not find any */
        IF not found THEN
          IF is_street THEN
            langcode=substring(local_name from position(':' in local_name)+1 for char_length(local_name));
            return(osml10n_street_abbrev(tags->local_name,langcode));
          ELSE
            return(tags->local_name);
          END IF;
        END IF;
      END IF;
    END IF;
  END IF;
  
  -- raise notice 'nobrackets: %',nobrackets;
  IF nobrackets THEN
    IF is_street THEN
      return(osml10n_street_abbrev_all(tags->name));
    ELSE
      return(tags->name);
    END IF;
  ELSE
   IF is_street THEN
     IF (position(':' in local_name) >0) THEN
       langcode=substring(local_name from position(':' in local_name)+1 for char_length(local_name));
       ln=osml10n_street_abbrev(tags->local_name,langcode);
     ELSE
       -- int_name case, we assume that this is in latin script
       ln=osml10n_street_abbrev_latin(tags->local_name);
     END IF;
     IF (position(':' in name) >0) THEN
       langcode=substring(name from position(':' in name)+1 for char_length(name));
       n=osml10n_street_abbrev(tags->name,langcode);
     ELSE
       if non_latin THEN
         n=osml10n_street_abbrev_non_latin(tags->name);
       -- only non-latin case is certain
       ELSE
         n=osml10n_street_abbrev_all(tags->name);
       END IF;
     END IF;
   ELSE
     n=tags->name;
     ln=tags->local_name;
   END IF;
   IF ( loc_in_brackets ) THEN
     -- explicitely mark the whole string as LTR
     IF ( show_brackets ) THEN
       return chr(8234)||n||separator||'('||ln||')'||chr(8236);
     ELSE
       return chr(8234)||n||separator||ln||chr(8236);
     END IF;
   ELSE
     -- explicitely mark the whole string as LTR
     IF ( show_brackets ) THEN
       return chr(8234)||ln||separator||'('||n||')'||chr(8236);
    ELSE
       return chr(8234)||ln||separator||n||chr(8236);
    END IF;
   END IF;
  END IF;
 END;
$combined$ LANGUAGE 'plpgsql' IMMUTABLE;


/*
Get name by looking at various name tags or transliteration as a last resort:

1. name:<targetlang>
2. name (if latin)
3. int_name (if latin)
5. name:en (if not targetlang)
5. name:fr (if not targetlang)
6. name:es (if not targetlang)
7: name:pt (if not targetlang)
8. name:de (if not targetlang)
9. Any tag of the form name:<targetlang>_rm or name:<targetlang>-Latn

This scheme is used in functions:
osml10n_get_name_from_tags and osml10n_get_name_without_brackets_from_tags

*/
CREATE or REPLACE FUNCTION osml10n_get_name_from_tags(tags hstore, 
                                                      loc_in_brackets boolean,
                                                      is_street boolean DEFAULT false,
                                                      show_brackets boolean DEFAULT false,
                                                      separator text DEFAULT chr(10),
                                                      targetlang text DEFAULT 'de',
                                                      place geometry DEFAULT NULL) RETURNS TEXT AS $$
 DECLARE
  -- 5 most commonly spoken languages using latin script (hopefully)   
  latin_langs text[] := '{"en","fr","es","pt","de"}';
  target_tag text;
  lang text;
  tag text;
 BEGIN
   target_tag := 'name:' || targetlang;
   IF tags ? target_tag THEN
     return osml10n_gen_combined_name(target_tag,'name',tags,loc_in_brackets,show_brackets,separator,is_street,true);
   END IF;
   IF tags ? 'name' THEN
     if (tags->'name' = '') THEN
       return '';
     END IF;
     IF osml10n_is_latin(tags->'name') THEN
       IF is_street THEN
         return(osml10n_street_abbrev_all(tags->'name'));
       ELSE
         return tags->'name';
       END IF;
     END IF;
     -- at this stage name is not latin so we need to have a look at alternatives
     -- these are currently int_name, common latin scripts and romanized version of the name
     IF tags ? 'int_name' THEN
       if osml10n_is_latin(tags->'int_name') THEN
         return osml10n_gen_combined_name('int_name','name',tags,loc_in_brackets,show_brackets,separator,is_street,false,true);
       END IF;
     END IF;
     
     -- if any latin language tag is available use it
     FOREACH lang IN ARRAY latin_langs
     LOOP
       -- we already checked for targetlang
       IF lang = targetlang THEN
         continue;
       END IF;
       target_tag := 'name:' || lang;
       if tags ? target_tag THEN
         -- raise notice 'found roman language tag %', target_tag;
         return osml10n_gen_combined_name(target_tag,'name',tags,loc_in_brackets,show_brackets,separator,is_street,true,true);
       END IF;
     END LOOP;
     -- try to find a romanized version of the name
     -- this usually looks like name:ja_rm or  name:ko-Latn
     -- Just use the first tag of this kind found, because
     -- having more than one of them does not make sense
     FOREACH tag IN ARRAY akeys(tags)
     LOOP
       IF ((tag ~ '^name:.+_rm$') or (tag ~ '^name:.+-Latn$')) THEN
         -- raise notice 'found romanization name tag %', tag;
         return osml10n_gen_combined_name(tag,'name',tags,loc_in_brackets,show_brackets,separator,is_street,true,true);
       END IF;
     END LOOP;
     IF is_street THEN
       tags := tags || hstore('name:Latn',osml10n_geo_translit(osml10n_street_abbrev_non_latin(tags->'name'),place));
     ELSE
       tags := tags || hstore('name:Latn',osml10n_geo_translit(tags->'name',place));
     END IF;
     return osml10n_gen_combined_name('name:Latn','name',tags,loc_in_brackets,show_brackets,separator,is_street,false,true);
   ELSE
     return NULL;
   END IF;
 END;
$$ LANGUAGE 'plpgsql' STABLE;

CREATE or REPLACE FUNCTION osml10n_get_name_without_brackets_from_tags(tags hstore,
                                                                       targetlang text DEFAULT 'de',
                                                                       place geometry DEFAULT NULL,
                                                                       name text DEFAULT NULL) RETURNS TEXT AS $$
 DECLARE
  -- 5 most commonly spoken languages using latin script (hopefully)   
  latin_langs text[] := '{"en","fr","es","pt","de"}';
  target_tag text;
  lang text;
  tag text;
 BEGIN
   IF (name IS NOT NULL) THEN
     tags := tags || hstore('name',name);
   END IF;
   target_tag := 'name:' || targetlang;
   IF tags ? target_tag THEN
     return tags->target_tag;
   END IF;
   IF tags ? 'name' THEN
     if (tags->'name' = '') THEN
       return '';
     END IF;
     IF osml10n_is_latin(tags->'name') THEN
       return tags->'name';
     END IF;
     -- at this stage name is not latin so we need to have a look at alternatives
     -- these are currently int_name, common latin scripts and romanized version of the name
     IF tags ? 'int_name' THEN
       IF osml10n_is_latin(tags->'int_name') THEN
         return tags->'int_name';
       END IF;
     END IF;
     
     -- if any latin language tag is available use it
     FOREACH lang IN ARRAY latin_langs
     LOOP
       -- we already checked for targetlang
       IF lang = targetlang THEN
         continue;
       END IF;
       target_tag := 'name:' || lang;
       if tags ? target_tag THEN
         -- raise notice 'found roman language tag %', target_tag;
         return tags->target_tag;
       END IF;
     END LOOP;
     -- try to find a romanized version of the name
     -- this usually looks like name:ja_rm or  name:ko-Latn
     -- Just use the first tag of this kind found, because
     -- having more than one of them does not make sense
     FOREACH tag IN ARRAY akeys(tags)
     LOOP
       IF ((tag ~ '^name:.+_rm$') or (tag ~ '^name:.+-Latn$')) THEN
         -- raise notice 'found romanization name tag %', tag;
         return tags->tag;
       END IF;
     END LOOP;
     -- raise notice 'last resort: doing transliteration';
     return osml10n_geo_translit(tags->'name',place);      
   ELSE
     return NULL;
   END IF;
 END;
$$ LANGUAGE 'plpgsql' STABLE;

/*

"exported functions"

*/
CREATE or REPLACE FUNCTION osml10n_get_placename_from_tags(tags hstore, 
                                                           loc_in_brackets boolean,
                                                           show_brackets boolean DEFAULT false,
                                                           separator text DEFAULT chr(10),
                                                           targetlang text DEFAULT 'de',
                                                           place geometry DEFAULT NULL,
                                                           name text DEFAULT NULL) RETURNS TEXT AS $$
 BEGIN
   -- workaround for openstreetmap carto database layout where name uses its own database column
   IF (name IS NOT NULL) THEN
     tags := tags || hstore('name',name);
   END IF;

   return(osml10n_get_name_from_tags(tags,loc_in_brackets,false,show_brackets,separator,targetlang,place));
 END;
$$ LANGUAGE 'plpgsql' STABLE;


CREATE or REPLACE FUNCTION osml10n_get_streetname_from_tags(tags hstore, 
                                                           loc_in_brackets boolean,
                                                           show_brackets boolean DEFAULT false,
                                                           separator text DEFAULT ' - ',
                                                           targetlang text DEFAULT 'de',
                                                           place geometry DEFAULT NULL,
                                                           name text DEFAULT NULL) RETURNS TEXT AS $$
 BEGIN
   -- workaround for openstreetmap carto database layout where name uses its own database column
   IF (name IS NOT NULL) THEN
     tags := tags || hstore('name',name);
   END IF;
   return(osml10n_get_name_from_tags(tags,loc_in_brackets,true,show_brackets,separator,targetlang,place));
 END;
$$ LANGUAGE 'plpgsql' STABLE;

-- pl/pgSQL code from file street_abbrv.sql -----------------------------------------------------------------
/*

renderer independent name localization
used in german mapnik style available at

https://github.com/giggls/openstreetmap-carto-de

(c) 2014-2016 Sven Geggus <svn-osm@geggus.net>

Licence AGPL http://www.gnu.org/licenses/agpl-3.0.de.html

Street abbreviation functions

*/

/* 
   helper function "osml10n_street_abbrev"
   will call the osml10n_street_abbrev function of the given language if available
   and return the unmodified input otherwise   
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev(longname text, langcode text) RETURNS TEXT AS $$
 DECLARE
  call text;
  func text;
  result text;
 BEGIN
  IF (position('-' in langcode)>0) THEN
    return longname;
  END IF;
  IF (position('_' in langcode)>0) THEN
    return longname;
  END IF;  
  func ='osml10n_street_abbrev_'|| langcode;
  call = 'select ' || func || '(' || quote_nullable(longname) || ')';
  execute call into result;
  return result;
 EXCEPTION
  WHEN undefined_function THEN
   return longname;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_all"
   call all osml10n_street_abbrev functions
   These are currently russian, english and german
   
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_all(longname text) RETURNS TEXT AS $$
 DECLARE
  abbrev text;
 BEGIN
  abbrev=osml10n_street_abbrev_de(longname);
  abbrev=osml10n_street_abbrev_en(abbrev);
  abbrev=osml10n_street_abbrev_ru(abbrev);
  abbrev=osml10n_street_abbrev_uk(abbrev);
  return abbrev;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_all_latin"
   call all latin osml10n_street_abbrev functions
   These are currently: english and german
   
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_latin(longname text) RETURNS TEXT AS $$
 DECLARE
  abbrev text;
 BEGIN
  abbrev=osml10n_street_abbrev_de(longname);
  abbrev=osml10n_street_abbrev_en(abbrev);
  return abbrev;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_non_latin"
   call all non latin osml10n_street_abbrev functions
   These are currently: russian, ukrainian
   
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_non_latin(longname text) RETURNS TEXT AS $$
 DECLARE
  abbrev text;
 BEGIN
  abbrev=osml10n_street_abbrev_ru(longname);
  abbrev=osml10n_street_abbrev_uk(abbrev);
  return abbrev;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;



/* 
   helper function "osml10n_street_abbrev_de"
   replaces some common parts of german street names with their abbr
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_de(longname text) RETURNS TEXT AS $$
 DECLARE
  abbrev text;
 BEGIN
  abbrev=longname;
  IF (position('traße' in abbrev)>2) THEN
   abbrev=regexp_replace(abbrev,'Straße\M','Str.');
   abbrev=regexp_replace(abbrev,'straße\M','str.');
  END IF;
  IF (position('asse' in abbrev)>2) THEN
   abbrev=regexp_replace(abbrev,'Strasse\M','Str.');
   abbrev=regexp_replace(abbrev,'strasse\M','str.');
   abbrev=regexp_replace(abbrev,'Gasse\M','G.');
   abbrev=regexp_replace(abbrev,'gasse\M','g.');
  END IF;
  IF (position('latz' in abbrev)>2) THEN
   abbrev=regexp_replace(abbrev,'Platz\M','Pl.');
   abbrev=regexp_replace(abbrev,'platz\M','pl.');
  END IF;
  IF (position('Professor' in abbrev)>0) THEN
   abbrev=replace(abbrev,'Professor ','Prof. ');
   abbrev=replace(abbrev,'Professor-','Prof.-');
  END IF;
  IF (position('Doktor' in abbrev)>0) THEN
   abbrev=replace(abbrev,'Doktor ','Dr. ');
   abbrev=replace(abbrev,'Doktor-','Dr.-');
  END IF;
  IF (position('Bürgermeister' in abbrev)>0) THEN
   abbrev=replace(abbrev,'Bürgermeister ','Bgm. ');
   abbrev=replace(abbrev,'Bürgermeister-','Bgm.-');
  END IF;
  IF (position('Sankt' in abbrev)>0) THEN
   abbrev=replace(abbrev,'Sankt ','St. ');
   abbrev=replace(abbrev,'Sankt-','St.-');
  END IF;
  return abbrev;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_fr"
   replaces some common parts of french street names with their abbreviation
   currently just a stub :(
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_fr(longname text) RETURNS TEXT AS $$
 BEGIN
  return longname;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_es"
   replaces some common parts of spanish street names with their abbreviation
   currently just a stub :(
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_es(longname text) RETURNS TEXT AS $$
 BEGIN
  return longname;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_pt"
   replaces some common parts of portuguese street names with their abbreviation
   currently just a stub :(
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_pt(longname text) RETURNS TEXT AS $$
 BEGIN
  return longname;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_en"
   replaces some common parts of english street names with their abbreviation
   Most common abbreviations extracted from:
   http://www.ponderweasel.com/whats-the-difference-between-an-ave-rd-st-ln-dr-way-pl-blvd-etc/
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_en(longname text) RETURNS TEXT AS $$
 DECLARE
  abbrev text;
 BEGIN
  abbrev=longname;
  abbrev=regexp_replace(abbrev,'Boulevard\M','Blvd.');
  abbrev=regexp_replace(abbrev,'Drive\M','Dr.');
  abbrev=regexp_replace(abbrev,'Avenue\M','Ave.');
  abbrev=regexp_replace(abbrev,'Street\M','St.');
  abbrev=regexp_replace(abbrev,'Road\M','Rd.');
  abbrev=regexp_replace(abbrev,'Lane\M','Ln.');
  abbrev=regexp_replace(abbrev,'Place\M','Pl.');
  abbrev=regexp_replace(abbrev,'Square\M','Sq.');
  abbrev=regexp_replace(abbrev,'Crescent\M','Cres.');
  return abbrev;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;



/* 
   helper function "osml10n_street_abbrev_ru"
   replaces улица (ulica) with ул. (ul.)
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_ru(longname text) RETURNS TEXT AS $$
 DECLARE
  abbrev text;
 BEGIN
  abbrev=regexp_replace(longname,'переулок','пер.');
  abbrev=regexp_replace(abbrev,'тупик','туп.');
  abbrev=regexp_replace(abbrev,'улица','ул.');
  abbrev=regexp_replace(abbrev,'бульвар','бул.');
  abbrev=regexp_replace(abbrev,'площадь','пл.');
  abbrev=regexp_replace(abbrev,'проспект','просп.');
  abbrev=regexp_replace(abbrev,'спуск','сп.');
  abbrev=regexp_replace(abbrev,'набережная','наб.');
  return abbrev;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

/* 
   helper function "osml10n_street_abbrev_uk"
   replaces ukrainian street suffixes with their abbreviations
*/
CREATE or REPLACE FUNCTION osml10n_street_abbrev_uk(longname text) RETURNS TEXT AS $$
 DECLARE
  abbrev text;
 BEGIN
  abbrev=regexp_replace(longname,'провулок','пров.');
  abbrev=regexp_replace(abbrev,'тупик','туп.');
  abbrev=regexp_replace(abbrev,'вулиця','вул.');
  abbrev=regexp_replace(abbrev,'бульвар','бул.');
  abbrev=regexp_replace(abbrev,'площа','пл.');
  abbrev=regexp_replace(abbrev,'проспект','просп.');
  abbrev=regexp_replace(abbrev,'спуск','сп.');
  abbrev=regexp_replace(abbrev,'набережна','наб.');
  return abbrev;
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;
-- country_osm_grid.sql -----------------------------------------------------------------

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

CREATE TABLE country_osm_grid (
    country_code character varying(2),
    area double precision,
    geometry geometry
);

COPY country_osm_grid (country_code, area, geometry) FROM '/usr/share/postgresql/9.6/extension/osml10n_country_osm_grid.data';

CREATE INDEX idx_country_osm_grid_geometry ON country_osm_grid USING gist (geometry);
GRANT SELECT on country_osm_grid to public;

-- country_languages table from http://wiki.openstreetmap.org/wiki/Nominatim/Country_Codes -----------------------------
CREATE TABLE country_languages(iso text, langs text[]);
COPY country_languages (iso, langs) FROM '/usr/share/postgresql/9.6/extension/country_languages.data';
GRANT SELECT on country_languages to public;


-- function osml10n_version  -----------------------------------------------------------------
CREATE or REPLACE FUNCTION osml10n_version() RETURNS TEXT AS $$
 BEGIN
  RETURN '2.5.5';
 END;
$$ LANGUAGE 'plpgsql' IMMUTABLE;

