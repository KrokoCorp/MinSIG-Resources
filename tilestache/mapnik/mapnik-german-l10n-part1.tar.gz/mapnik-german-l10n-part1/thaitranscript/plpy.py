def notice(txt):
    print(txt)
