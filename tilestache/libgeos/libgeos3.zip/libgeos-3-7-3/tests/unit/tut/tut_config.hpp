#ifndef TUT_CONFIG_H_GUARD
#define TUT_CONFIG_H_GUARD

#define TUT_USE_RTTI 1

#endif
